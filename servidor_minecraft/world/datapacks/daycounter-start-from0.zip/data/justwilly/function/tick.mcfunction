execute store result score $day daycounter run time query time
scoreboard players operation $day daycounter /= #ticks_per_day daycounter
scoreboard players add $day daycounter 0
title @a actionbar [{"text":"DAY ","color":"white"},{"score":{"name":"$day","objective":"daycounter"}}]